
void filter2d_mean3(double * img_in, long width, long height, double * img_out);

void sobel_norm(double * img_in, long width, long height, double * img_out);

void filter2d_gaussian(double * img_in, long width, long height, double sigma, double * img_out);


void img_get_raw(double * img, long width, long height,
		             long no,
						     double * v);
void img_set_raw(double * img, long width, long height,
								 long no,
								 double * v);
void img_get_column(double * img, long width, long height,
									  long no,
										double * v);
void img_set_column(double * img, long width, long height,
										long no,
										double * v);

void filter2d_gaussian_fast(double * img_in, long width, long height, double sigma, double * img_out);

void filter2d_by_method(double * img_in, long width, long height,
	                      long tx, long ty, long method,
												double * img_out);


