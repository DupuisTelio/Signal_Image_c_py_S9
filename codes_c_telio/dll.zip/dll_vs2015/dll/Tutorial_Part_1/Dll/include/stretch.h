

void img_stretch_intensity(double * img_in, long width, long height, double * img_out);
