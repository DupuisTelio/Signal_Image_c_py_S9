

void img_equalize_histogram(double * img_in, long width, long height,
														long nb_levels,
														double * img_out);
							