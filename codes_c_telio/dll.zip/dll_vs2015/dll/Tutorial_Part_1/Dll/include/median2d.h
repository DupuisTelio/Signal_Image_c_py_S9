

void filter2d_median(double * img_in, long width, long height,
										 long tx, long ty,
									   double * img_out);
					 