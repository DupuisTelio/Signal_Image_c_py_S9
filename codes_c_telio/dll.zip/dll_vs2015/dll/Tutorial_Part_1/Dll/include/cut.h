

void img_extract_area(unsigned char * img_color_in, long width, long height,
											long x, long y, long dx, long dy,
											unsigned char * img_color_out);
					  