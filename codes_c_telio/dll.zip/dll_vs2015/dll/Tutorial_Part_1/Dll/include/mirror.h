
void img_mirror_horizontal(double * img_in, long width, long height,
						               double * img_out);
							 