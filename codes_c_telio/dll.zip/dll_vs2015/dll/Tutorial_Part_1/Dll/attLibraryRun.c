
#include <malloc.h>
#include <string.h>

/* Liste des fonctions N'D */
#include <callback.h>

/* Listes des codes appel�s dans la librairie */
#include <stretch.h>
#include <filter2d.h>
#include <equalize.h>
#include <color.h>
#include <mirror.h>
#include <cut.h>
#include <rotate.h>
#include <median2d.h>


/* Liste des fonctions associ�es aux entr�es des menus */

static void On_Menu1()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;	
			
	/* D�claration d'une image d'entr�e avec gestion d'erreur */
	id_in = ndImageGetIn();
	if ( !id_in ) return;				
	ndImageGetSize(id_in, &w_in, &h_in);	
	/* Obtention d'une copie de l'image d'entr�e, au format souhait�, avec gestion d'erreur */
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);					
	if ( in_f == NULL ) return;
	/* D�claration d'une image de sortie */
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	/* Obtention d'un pointeur sur l'image de sortie */
	out_f = (double *)ndImageGetPtrData(id_out);						
	img_stretch_intensity(in_f, w_in, h_in, out_f);	
	/* Lib�ration de l'image d'entr�e */
	ndFree(in_f);
}


static void On_Menu2()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;	
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;				
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);					
	if ( in_f == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	out_f = (double *)ndImageGetPtrData(id_out);						
	filter2d_mean3(in_f, w_in, h_in, out_f);	
	ndFree(in_f);
}


static void On_Menu3()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;	
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;				
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);					
	if ( in_f == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	out_f = (double *)ndImageGetPtrData(id_out);						
	sobel_norm(in_f, w_in, h_in, out_f);	
	ndFree(in_f);
}


static void On_Menu4()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;
	static double sigma = 4.0;	
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;				
	if ( !ndBoxParameter("Sigma%f", &sigma) ) return;		
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);					
	if ( in_f == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	out_f = (double *)ndImageGetPtrData(id_out);						
	filter2d_gaussian(in_f, w_in, h_in, sigma, out_f);	
	ndFree(in_f);
}


static void On_Menu5()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;
	static double sigma = 4.0;	
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;				
	if ( !ndBoxParameter("Sigma%f", &sigma) ) return;		
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);					
	if ( in_f == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	out_f = (double *)ndImageGetPtrData(id_out);						
	filter2d_gaussian_fast(in_f, w_in, h_in, sigma, out_f);	
	ndFree(in_f);
}


static void On_Menu6()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;
	static long nb_levels = 50;	
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;				
	if ( !ndBoxParameter("Nombre de niveaux%d", &nb_levels) ) return;		
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);					
	if ( in_f == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	out_f = (double *)ndImageGetPtrData(id_out);						
	img_equalize_histogram(in_f, w_in, h_in, nb_levels, out_f);	
	ndFree(in_f);
}


static void On_Menu7()
{
	long w_in, h_in, id_in, id_out;
	unsigned char * in_b, * out_b;
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;				
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_b = (unsigned char *)ndImageGetData(id_in, TYPE_RGBA);					
	if ( in_b == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_RGBA);
	ndImageShow(id_out);		
	out_b = (unsigned char *)ndImageGetPtrData(id_out);						
	img_reduce_colors_to_216(in_b, w_in, h_in, out_b);	
	ndFree(in_b);
}


static void On_Menu8()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;	
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;					
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);					
	if ( in_f == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	out_f = (double *)ndImageGetPtrData(id_out);						
	img_mirror_horizontal(in_f, w_in, h_in, out_f);	
	ndFree(in_f);
}


static void On_Menu9()
{
	long w_in, h_in, id_in, id_out;
	unsigned char * in_b, * out_b;	
	static long x = 0, y = 0, dx = 1, dy = 1;
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;					
	if ( !ndBoxParameter("X%dY%ddX%ddY%d", &x, &y ,&dx, &dy) ) return;		
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_b = (unsigned char *)ndImageGetData(id_in, TYPE_RGBA);					
	if ( in_b == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, dx, dy);
	ndImageSetTypeData(id_out, TYPE_RGBA);
	ndImageShow(id_out);		
	out_b = (unsigned char *)ndImageGetPtrData(id_out);						
	img_extract_area(in_b, w_in, h_in, x, y, dx ,dy, out_b);	
	ndFree(in_b);
}


static void On_Menu10()
{
	long w_in, h_in, id_in, id_out, type_data;
	void * in, * out;		
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;						
	type_data = ndImageGetTypeData(id_in);
	if ( type_data != TYPE_DOUBLE && type_data != TYPE_RGBA ) return;
	ndImageGetSize(id_in, &w_in, &h_in);	
	in = ndImageGetData(id_in, type_data);						
	if ( in == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, h_in, w_in);
	ndImageSetTypeData(id_out, type_data);
	ndImageShow(id_out);		
	out = ndImageGetPtrData(id_out);	
	if ( type_data == TYPE_DOUBLE )
		type_data = 0;
	else
		type_data = 1;
	img_rotate(in, w_in, h_in, type_data, out);	
	ndFree(in);
}


static void On_Menu11()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;		
	static long tx = 5, ty = 5;
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;							
	if ( !ndBoxParameter("Tx%dTy%d%n", &tx, &ty) ) return;		
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);						
	if ( in_f == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	out_f = ndImageGetPtrData(id_out);		
	filter2d_median(in_f, w_in, h_in, tx, ty, out_f);	
	ndFree(in_f);
}


static void On_Menu12()
{
	long w_in, h_in, id_in, id_out;
	double * in_f, * out_f;		
	static long tx = 5, ty = 5, method = 0;
			
	id_in = ndImageGetIn();
	if ( !id_in ) return;							
	if ( !ndBoxParameter("Min,Max,Mean,Median%lTx%dTy%d%n", &method, &tx, &ty) ) return;		
	ndImageGetSize(id_in, &w_in, &h_in);	
	in_f = (double *)ndImageGetData(id_in, TYPE_DOUBLE);						
	if ( in_f == NULL ) return;
	id_out = ndImageNew();
	ndImageSetSize(id_out, w_in, h_in);
	ndImageSetTypeData(id_out, TYPE_DOUBLE);
	ndImageShow(id_out);		
	out_f = ndImageGetPtrData(id_out);		
	filter2d_by_method(in_f, w_in, h_in, tx, ty, method, out_f);	
	ndFree(in_f);
}



EXPORT_LIB void attLibraryInit(long id_library)
{
	long menu; 

	menu = ndMenuCreate("Langage C pour le TSI");
	ndMenuAddItem(menu, "Changement de dynamique",							On_Menu1);
	ndMenuAddItem(menu, "Moyenneur rectangle",									On_Menu2);
	ndMenuAddItem(menu, "Norme du gradient de Sobel",						On_Menu3);
	ndMenuAddItem(menu, "Filtrage gaussien",										On_Menu4);
	ndMenuAddItem(menu, "Filtrage gaussien - version rapide",		On_Menu5);
	ndMenuAddItem(menu, "Egalisation d'histogramme",						On_Menu6);
	ndMenuAddItem(menu, "R�duction du nombre de couleurs",			On_Menu7);
	ndMenuAddItem(menu, "Miroir horizontal",										On_Menu8);
	ndMenuAddItem(menu, "D�coupe couleur",											On_Menu9);
	ndMenuAddItem(menu, "Rotation +90�",												On_Menu10);
	ndMenuAddItem(menu, "Filtre m�dian 2D",											On_Menu11);
	ndMenuAddItem(menu, "Filtre 2D libre",											On_Menu12);
	ndLibraryAddMenu(id_library, "MENU_2D", menu);
}


EXPORT_LIB void attLibraryEnd(long id_library)
{
}








