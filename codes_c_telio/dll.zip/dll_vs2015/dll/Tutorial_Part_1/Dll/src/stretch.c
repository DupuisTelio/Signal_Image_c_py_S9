

#include <stretch.h>


static void v_compute_min_max(double * v_in, long size, double * v_min, double * v_max)
{
}


void img_stretch_intensity(double * img_in, long width, long height, double * img_out)
{
}