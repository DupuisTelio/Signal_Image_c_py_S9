

#include <color.h>


void img_reduce_colors_to_216(unsigned char * img_color_in,
															long width, long height,
															unsigned char * img_color_out)
{
}




