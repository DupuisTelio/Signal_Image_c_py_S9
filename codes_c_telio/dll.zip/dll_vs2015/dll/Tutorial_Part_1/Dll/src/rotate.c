

#include <rotate.h>


void img_rotate(void * img_in, long width, long height,
								long type_data,
								void * img_out)
{
}