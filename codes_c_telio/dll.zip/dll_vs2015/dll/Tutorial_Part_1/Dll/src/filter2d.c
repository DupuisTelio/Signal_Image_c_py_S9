
#include <stdio.h>


#include <filter2d.h>


void filter2d_mean3(double * img_in, long width, long height, double * img_out)
{
	
}


void sobel_norm(double * img_in, long width, long height, double * img_out)
{
	
}


static double * gaussian2d_create(double sigma, long * size)
{
	return NULL;
}


static void convolution2d(double * img_in, long width, long height,
									        double * mask2d, long tx, long ty,
									        double * img_out)
{
}

static double ** gaussian2d_create_matrix(double sigma, long * size)
{
	return NULL;
}


static void convolution2d_by_matrix(double * img_in, long width, long height,
																		double ** mask2d, long tx, long ty,
									                  double * img_out)
{
}


void filter2d_gaussian(double * img_in, long width, long height,
											 double sigma,
											 double * img_out)
{
}


void img_get_raw(double * img, long width, long height,
		             long no,
						     double * v)
{
}


void img_set_raw(double * img, long width, long height,
								 long no,
								 double * v)
{
}


void img_get_column(double * img, long width, long height,
									  long no,
										double * v)
{
}


void img_set_column(double * img, long width, long height,
										long no,
										double * v)
{
}


static double * gaussian1d_create(double sigma, long * size)
{
	return NULL;
}


static void convolution1d(double * v_in, long size,
													double * mask1d, long t,
													double * v_out)
{
}


void filter2d_gaussian_fast(double * img_in, long width, long height,
														double sigma,
														double * img_out)
{
}


typedef double (* PROC)(double *, long);


static void filter2d_generic(double * img_in, long width, long height,
							  						 long tx, long ty, PROC proc,
														 double * img_out)
{
}


void filter2d_by_method(double * img_in, long width, long height,
	                      long tx, long ty, long method,
												double * img_out)
{
}




