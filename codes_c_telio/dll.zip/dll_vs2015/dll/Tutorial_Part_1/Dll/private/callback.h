

/*80*************************************************************************************/
/*80*************************************************************************************/
/*80********************************** NOT TO MODIFY ************************************/
/*80*************************************************************************************/
/*80*************************************************************************************/


#if !defined (LIBRARY_CALLBACK)
	#define LIBRARY_CALLBACK

#if !defined(EXPORT_LIB)
	#define EXPORT_LIB __declspec (dllexport)
#endif

typedef void				(*attfunc)										();
typedef attfunc			(*attfunc_functioncallback)		(char *);
typedef long				(*attfunc_function_callback)	(long id, void * data_event, void * data_callback);

#define RET_VOID		(void)(( void(*)
#define RET_LONG		(long)(( long(*)
#define RET_PVOID		(void *)(( void *(*)
#define RET_PCHAR		(char *)(( char *(*)
#define ATT_CALL		)(function_callback

#if defined(LIBRARY_MAIN)	
	attfunc_functioncallback					function_callback;
#else
	extern attfunc_functioncallback		function_callback;
#endif


// Types de donn�es

#define TYPE_BYTE						1				// entier 8 bits non sign� [0,255]
#define TYPE_CHAR						2				// entier 8 bits sign� [-128,127]
#define TYPE_DOUBLE					3				// virgule flottante sur 64 bits
#define TYPE_FLOAT					4				// virgule flottante sur 32 bits
#define TYPE_SHORT					5				// entier 16 bits sign� [-32768,32767]
#define TYPE_LONG						6				// entier 32 bits sign�
#define TYPE_RGBA						7				// quadruplet (R,G,B,A) 4x8 bits
#define TYPE_UCHAR					1				// entier 8 bits non sign� [0,255]
#define TYPE_USHORT					8				// entier 16 bits non sign� [0,65535]
#define TYPE_ULONG					9				// entier 32 bits non sign�

	

// D�clarations

#define ndImageGetIn	\
				RET_LONG() \
				ATT_CALL("ndImageGetIn")))

#define ndBlockGetIn	\
				RET_LONG() \
				ATT_CALL("ndBlockGetIn")))

#define ndStudyGetIn	\
				RET_LONG() \
				ATT_CALL("ndStudyGetIn")))

#define ndView3dGetIn	\
				RET_LONG() \
				ATT_CALL("ndView3dGetIn")))

#define ndImageNew	\
				RET_LONG() \
				ATT_CALL("ndImageNew")))

#define ndBlockNew	\
				RET_LONG() \
				ATT_CALL("ndBlockNew")))

#define ndGraphNew	\
				RET_LONG() \
				ATT_CALL("ndGraphNew")))

#define ndView3dNew	\
				RET_LONG() \
				ATT_CALL("ndView3dNew")))


// Initialisations

#define ndImageSetTypeData	\
				RET_VOID(long id, long type_data) \
				ATT_CALL("ndImageSetTypeData")))

#define ndImageSetSize	\
				RET_VOID(long id, long width, long height) \
				ATT_CALL("ndImageSetSize")))

#define ndBlockSetTypeData	\
				RET_VOID(long id, long type_data) \
				ATT_CALL("ndBlockSetTypeData")))

#define ndBlockSetSize	\
				RET_VOID(long id, long width, long height, long depth) \
				ATT_CALL("ndBlockSetSize")))

#define DECL_FILE							1
#define DECL_FILE_TRANSPOSE		2	

#define ndBlockSetFile	\
				RET_VOID(long id, long filetype, char * filename) \
				ATT_CALL("ndBlockSetFile")))

#define ndBlockSetMemory	\
				RET_VOID(long id) \
				ATT_CALL("ndBlockSetMemory")))

#define ndGraphSetSize	\
				RET_VOID(long id, long width, long height) \
				ATT_CALL("ndGraphSetSize")))


// Cr�ations

#define ndImageShow	\
				RET_VOID(long id) \
				ATT_CALL("ndImageShow")))

#define ndBlockShow	\
				RET_VOID(long id) \
				ATT_CALL("ndBlockShow")))

#define ndGraphShow	\
				RET_VOID(long id) \
				ATT_CALL("ndGraphShow")))

#define ndView3dShow	\
				RET_VOID(long id) \
				ATT_CALL("ndView3dShow")))


// IMAGES 2D

#define ndImageGetSize	\
				RET_VOID(long id, long * width, long * height) \
				ATT_CALL("ndImageGetSize")))

#define ndImageGetClickNumber	\
				RET_LONG(long id) \
				ATT_CALL("ndImageGetClickNumber")))

#define ndImageGetClickArray \
				RET_VOID(long id, long ** array_x, long ** array_y) \
				ATT_CALL("ndImageGetClickArray")))

#define ndImageGetCaptureNumber	\
				RET_LONG(long id) \
				ATT_CALL("ndImageGetCaptureNumber")))

#define ndImageGetCaptureArray \
				RET_VOID(long id, long ** array_x, long ** array_y) \
				ATT_CALL("ndImageGetCaptureArray")))

#define ndImageGetData \
				RET_PVOID(long id, long type_data) \
				ATT_CALL("ndImageGetData")))

#define ndImageGetPtrData	\
				RET_PVOID(long id) \
				ATT_CALL("ndImageGetPtrData")))

#define ndImageGetTypeData \
				RET_LONG(long id) \
				ATT_CALL("ndImageGetTypeData")))

// Types de classes
#define CLASS_DEFAULT				0
#define CLASS_LABEL					1
#define CLASS_DIRECTION			2
#define CLASS_BOOLEAN				3
#define CLASS_ORIENTATION		4

#define ndImageSetClass	\
				RET_VOID(long id, long type_class) \
				ATT_CALL("ndImageSetClass")))

#define ndImageAddObject2d \
				RET_VOID(long id, long id_object2d) \
				ATT_CALL("ndImageAddObject2d")))

#define ndImageDeleteObject2d \
				RET_VOID(long id, long id_object2d) \
				ATT_CALL("ndImageDeleteObject2d")))

#define ndImageDeleteObject2dByName \
				RET_VOID(long id, char * name) \
				ATT_CALL("ndImageDeleteObject2dByName")))

#define ndImageAddLine \
				RET_LONG(long id, double x1, double y1, double x2, double y2) \
				ATT_CALL("ndImageAddLine")))

#define ndImageAddSquare \
				RET_LONG(long id, double x, double y, double c) \
				ATT_CALL("ndImageAddSquare")))

#define ndImageSaveBitmap \
				RET_LONG(long id, char * filename) \
				ATT_CALL("ndImageSaveBitmap")))


// IMAGES 3D

#define ndBlockGetSize \
				RET_VOID(long id, long * width, long * height, long * depth) \
				ATT_CALL("ndBlockGetSize")))

#define ndBlockGetFront	\
				RET_PVOID(long id, long no, long type_data) \
				ATT_CALL("ndBlockGetFront")))

#define ndBlockGetPartialFront \
				RET_PVOID(long id, long no, long type_data, long x, long y, long dx, long dy) \
				ATT_CALL("ndBlockGetPartialFront")))

#define ndBlockGetRight	\
				RET_PVOID(long id, long no, long type_data) \
				ATT_CALL("ndBlockGetRight")))

#define ndBlockGetPartialRight \
				RET_PVOID(long id, long no, long type_data, long x, long y, long dx, long dy) \
				ATT_CALL("ndBlockGetPartialRight")))

#define ndBlockGetTop	\
				RET_PVOID(long id, long no, long type_data) \
				ATT_CALL("ndBlockGetTop")))

#define ndBlockGetPartialTop \
				RET_PVOID(long id, long no, long type_data, long x, long y, long dx, long dy) \
				ATT_CALL("ndBlockGetPartialTop")))

#define ndBlockGetImageFromTopPatch	\
				RET_PVOID(long id, long no, long type_data, long * patch_dx, long * patch_dy, long nb, long * width, long * height) \
				ATT_CALL("ndBlockGetImageFromTopPatch")))

#define ndBlockGetImageSONE	\
				RET_PVOID(long id, long no, long type_data, long * width, long * height) \
				ATT_CALL("ndBlockGetImageSONE")))

#define ndBlockGetImageNOSE	\
				RET_PVOID(long id, long no, long type_data, long * width, long * height) \
				ATT_CALL("ndBlockGetImageNOSE")))

// Type d'op�ration de mise � jour sur fichier
#define ATT_OP_COPY					0
#define ATT_OP_ADD					1
#define ATT_OP_MUL					2
#define ATT_OP_MIN					3
#define ATT_OP_MAX					4
#define ATT_OP_NONE					99

#define ndBlockSetUpdateFile \
				RET_VOID(long id, long type_update) \
				ATT_CALL("ndBlockSetUpdateFile")))

#define ndBlockSetPartialFront \
				RET_VOID(long id, long no, long x, long y, void * data, long w, long h) \
				ATT_CALL("ndBlockSetPartialFront")))

#define ndBlockSetFront	\
				RET_VOID(long id, long no, void * data) \
				ATT_CALL("ndBlockSetFront")))

#define ndBlockSetFrontByType	\
				RET_VOID(long id, long no, void * data, long type_data) \
				ATT_CALL("ndBlockSetFrontByType")))

#define ndBlockSetPartialFrontByType \
				RET_VOID(long id, long no, long x, long y, void * data, long w, long h, long type_data) \
				ATT_CALL("ndBlockSetPartialFrontByType")))

#define ndBlockSetPartialRight \
				RET_VOID(long id, long no, long x, long y, void * data, long w, long h) \
				ATT_CALL("ndBlockSetPartialRight")))

#define ndBlockSetRight	\
				RET_VOID(long id, long no, void * data) \
				ATT_CALL("ndBlockSetRight")))

#define ndBlockSetRightByType	\
				RET_VOID(long id, long no, void * data, long type_data) \
				ATT_CALL("ndBlockSetRightByType")))

#define ndBlockSetPartialRightByType \
				RET_VOID(long id, long no, long x, long y, void * data, long w, long h, long type_data) \
				ATT_CALL("ndBlockSetPartialRightByType")))

#define ndBlockSetPartialTop \
				RET_VOID(long id, long no, long x, long y, void * data, long w, long h) \
				ATT_CALL("ndBlockSetPartialTop")))

#define ndBlockSetTop	\
				RET_VOID(long id, long no, void * data) \
				ATT_CALL("ndBlockSetTop")))

#define ndBlockSetTopByType	\
				RET_VOID(long id, long no, void * data, long type_data) \
				ATT_CALL("ndBlockSetTopByType")))

#define ndBlockSetPartialTopByType \
				RET_VOID(long id, long no, long x, long y, void * data, long w, long h, long type_data) \
				ATT_CALL("ndBlockSetPartialTopByType")))

#define ndBlockSetImageSONE	\
				RET_VOID(long id, long no, void * data) \
				ATT_CALL("ndBlockSetImageSONE")))

#define ndBlockSetImageSONEByType	\
				RET_VOID(long id, long no, void * data, long type_data) \
				ATT_CALL("ndBlockSetImageSONEByType")))

#define ndBlockSetImageNOSE	\
				RET_VOID(long id, long no, void * data) \
				ATT_CALL("ndBlockSetImageNOSE")))

#define ndBlockSetImageNOSEByType	\
				RET_VOID(long id, long no, void * data, long type_data) \
				ATT_CALL("ndBlockSetImageNOSEByType")))

#define ndBlockGetClickNumber	\
				RET_LONG(long id) \
				ATT_CALL("ndBlockGetClickNumber")))

#define ndBlockGetClickArray \
				RET_VOID(long id, long ** array_x, long ** array_y, long ** array_z) \
				ATT_CALL("ndBlockGetClickArray")))

#define ndBlockGetCaptureNumber	\
				RET_LONG(long id) \
				ATT_CALL("ndBlockGetCaptureNumber")))

#define ndBlockGetCaptureArray \
				RET_VOID(long id, long ** array_x, long ** array_y, long ** array_z) \
				ATT_CALL("ndBlockGetCaptureArray")))

#define ndBlockGetCursor	\
				RET_LONG(long id, long * x, long * y, long * z) \
				ATT_CALL("ndBlockGetCursor")))

#define ndBlockGetPtrData	\
				RET_PVOID(long id) \
				ATT_CALL("ndBlockGetPtrData")))

#define ndBlockGetTypeData \
				RET_LONG(long id) \
				ATT_CALL("ndBlockGetTypeData")))

#define ndBlockSetClass	\
				RET_VOID(long id, long type_class) \
				ATT_CALL("ndBlockSetClass")))


// GRAPHES


// VUES 3D

#define ndView3dGetSize \
				RET_VOID(long id, long * width, long * height, long * depth) \
				ATT_CALL("ndView3dGetSize")))

#define ndView3dAddObject3d \
				RET_VOID(long id, long id_object3d) \
				ATT_CALL("ndView3dAddObject3d")))

#define ndView3dDeleteObject3d \
				RET_VOID(long id, long id_object3d) \
				ATT_CALL("ndView3dDeleteObject3d")))

#define ndView3dDeleteObject3dByName \
				RET_VOID(long id, char * name) \
				ATT_CALL("ndView3dDeleteObject3dByName")))



// VIDEO

#define ndVideoGetId	\
				RET_LONG() \
				ATT_CALL("ndVideoGetId")))

#define ndVideoGetTime	\
				RET_LONG() \
				ATT_CALL("ndVideoGetTime")))

#define ndVideoSetFormatIn	\
				RET_VOID(long id, long format) \
				ATT_CALL("ndVideoSetFormatIn")))

#define ndVideoSetFormatOut	\
				RET_VOID(long id, long format) \
				ATT_CALL("ndVideoSetFormatOut")))

#define ndVideoGetDataIn	\
				RET_PVOID(long id) \
				ATT_CALL("ndVideoGetDataIn")))

#define ndVideoGetDataOut	\
				RET_PVOID(long id) \
				ATT_CALL("ndVideoGetDataOut")))

#define ndVideoGetWidth	\
				RET_LONG(long id) \
				ATT_CALL("ndVideoGetWidth")))

#define ndVideoGetHeight \
				RET_LONG(long id) \
				ATT_CALL("ndVideoGetHeight")))

#define ndVideoGetUserData \
				RET_PVOID(long id) \
				ATT_CALL("ndVideoGetUserData")))

#define ndVideoSetUserData \
				RET_VOID(long id, void * user_data) \
				ATT_CALL("ndVideoSetUserData")))

#define ndVideoStart \
				RET_VOID(long id, attfunc VideoOn, attfunc VideoOff) \
				ATT_CALL("ndVideoStart")))



// PROGRESSION DES CALCULS

#define ndProgressSetMinMax	\
				RET_VOID(long mini, long maxi) \
				ATT_CALL("ndProgressSetMinMax")))

#define ndProgressSetPosition	\
				RET_VOID(long position) \
				ATT_CALL("ndProgressSetPosition")))

#define ndProgressReset	\
				RET_VOID() \
				ATT_CALL("ndProgressReset")))


// DIVERS

#define ndFree	\
				RET_VOID(void * ptr) \
				ATT_CALL("ndFree")))

#define ndPopupImage \
				RET_LONG(void * data, long w, long h, long type_data) \
				ATT_CALL("ndPopupImage")))

#define ndPopupHistogram \
				RET_LONG(void * data, long length, long type_data) \
				ATT_CALL("ndPopupImage")))

#define ndLoadFromFile \
				RET_VOID(char * filename) \
				ATT_CALL("ndLoadFromFile")))

#define ndMsg \
				RET_VOID(char * message) \
				ATT_CALL("ndMsg")))

#define ndMsgFormat \
				RET_VOID(char * format, ...) \
				ATT_CALL("ndMsgFormat")))


#define ndLibraryAddMenu \
				RET_VOID(long id_library, char * insert, long menu) \
				ATT_CALL("ndLibraryAddMenu")))

#define ndMenuCreate \
				RET_LONG(char * title) \
				ATT_CALL("ndMenuCreate")))

#define ndMenuAddItem \
				RET_VOID(long menu, char * title, attfunc function) \
				ATT_CALL("ndMenuAddItem")))

#define ndMenuAddSeparator \
				RET_VOID(long menu) \
				ATT_CALL("ndMenuAddSeparator")))

#define ndMenuAddSubMenu \
				RET_VOID(long menu, long submenu) \
				ATT_CALL("ndMenuAddSubMenu")))

#define ndBoxParameter	\
				RET_LONG(char * string, ...) \
				ATT_CALL("ndBoxParameter")))

#define ndBoxParameterAdd	\
				RET_PVOID(void * data, char * string, ...) \
				ATT_CALL("ndBoxParameterAdd")))

#define ndBoxParameterDialog	\
				RET_LONG(void * data) \
				ATT_CALL("ndBoxParameterDialog")))

#define ndWindowRedraw	\
				RET_VOID(long id_object) \
				ATT_CALL("ndWindowRedraw")))

#define ndWindowSetName \
				RET_VOID(long id_object, const char * name) \
				ATT_CALL("ndWindowSetName")))

#define ndWindowUserDataNew	\
				RET_VOID(long id_object, char * name) \
				ATT_CALL("ndWindowUserDataNew")))

#define ndWindowUserDataDelete	\
				RET_VOID(long id_object, char * name) \
				ATT_CALL("ndWindowUserDataDelete")))

#define ndWindowUserDataSet	\
				RET_VOID(long id_object, char * name, void * ptr) \
				ATT_CALL("ndWindowUserDataSet")))

#define ndWindowUserDataGet	\
				RET_PVOID(long id_object, char * name) \
				ATT_CALL("ndWindowUserDataGet")))


/*
		Callbacks Interface

IMAGE_IN, IMAGE_OUT
			"LBUTTONDOWN"				-> "x", "y", "x_image", "y_image", "x_screen", "y_screen"
			"LBUTTONUP"					-> "x", "y", "x_image", "y_image", "x_screen", "y_screen"
			"LBUTTONDBLCLICK"
			"MBUTTONDOWN"				-> "x", "y", "x_image", "y_image", "x_screen", "y_screen"
			"MBUTTONUP"					-> "x", "y", "x_image", "y_image", "x_screen", "y_screen"
			"MBUTTONDBLCLICK"
			"RBUTTONDOWN"				-> "x", "y", "x_image", "y_image", "x_screen", "y_screen"
			"RBUTTONUP"					-> "x", "y", "x_image", "y_image", "x_screen", "y_screen"
			"RBUTTONDBLCLICK"
			"MOUSEMOVE"					-> "x", "y", "x_image", "y_image", "x_screen", "y_screen"			
			"MSG_HOOK"					-> "hWnd", "msg", "wparam", "lparam"
*/

#define ndWindowCallbackAdd \
				RET_VOID(long id_object, char * name, attfunc_function_callback function_callback, void * data_callback) \
				ATT_CALL("ndWindowCallbackAdd")))

#define ndWindowCallbackSub \
				RET_VOID(long id_object, char * name, attfunc_function_callback function_callback) \
				ATT_CALL("ndWindowCallbackSub")))

#define ndWindowCallbackEventGet \
				RET_LONG(long id_object, void * data_event, char * name_event, void * data_to_get) \
				ATT_CALL("ndWindowCallbackEventGet")))

#define ndWindowCallbackEventSet \
				RET_LONG(long id_object, void * data_event, char * name_event, void * data_to_set) \
				ATT_CALL("ndWindowCallbackEventSet")))


// OBJETS 2D

typedef struct _PT2D
{
	double x;
	double y;	
} PT2D;

#define OBJECT2D_SETOFPOINTS	0
#define OBJECT2D_LINE					1
#define OBJECT2D_POLYGON			2
#define OBJECT2D_CIRCLE				3
#define OBJECT2D_ASTERISK			4
#define OBJECT2D_ARROW				5
#define OBJECT2D_SQUARE				6

#define ndObject2dCreate \
				RET_LONG(long type) \
				ATT_CALL("ndObject2dCreate")))

#define ndObject2dSetName \
				RET_VOID(long id_object2d, char * name) \
				ATT_CALL("ndObject2dSetName")))

#define ndObject2dSetColor \
				RET_VOID(long id_object2d, double r, double g, double b) \
				ATT_CALL("ndObject2dSetColor")))

#define ndObject2dSetThickness \
				RET_VOID(long id_object2d, long thickness) \
				ATT_CALL("ndObject2dSetThickness")))

#define ndObject2dSetArrayPoints \
				RET_VOID(long id_object2d, PT2D * array_pt2d, long nb_pt2d) \
				ATT_CALL("ndObject2dSetArrayPoints")))

#define ndObject2dTranslate \
				RET_VOID(long id_object2d, double sx, double sy) \
				ATT_CALL("ndObject2dTranslate")))

#define ndObject2dScale \
				RET_VOID(long id_object2d, double sx, double sy) \
				ATT_CALL("ndObject2dScale")))


// OBJETS 3D

typedef struct _PT3D
{
	double x;
	double y;
	double z;
} PT3D;

typedef struct _MESH3D
{
	long nb_pt;
	PT3D * array_pt3d;
	long nb_triangle;
	long * array_triangle;
	void * unknown;
} MESH3D;


#define ndMesh3dCube \
				RET_PVOID(void) \
				ATT_CALL("ndMesh3dCube")))

#define ndMesh3dSphere \
				RET_PVOID(long precision) \
				ATT_CALL("ndMesh3dSphere")))

#define ndMesh3dCylinder \
				RET_PVOID(long precision) \
				ATT_CALL("ndMesh3dCylinder")))

#define ndMesh3dArrow \
				RET_PVOID(PT3D * pt_begin, PT3D * pt_end, double radius) \
				ATT_CALL("ndMesh3dArrow")))

#define ndMesh3dReadFromFile \
				RET_PVOID(char * filename) \
				ATT_CALL("ndMesh3dReadFromFile")))

#define ndMesh3dAlloc \
				RET_PVOID(long nb_pt, long nb_triangle) \
				ATT_CALL("ndMesh3dAlloc")))

#define ndMesh3dFree \
				RET_PVOID(MESH3D * mesh3d) \
				ATT_CALL("ndMesh3dFree")))

#define ndMesh3dScale \
				RET_VOID(MESH3D * mesh3d, double sx, double sy, double sz) \
				ATT_CALL("ndMesh3dScale")))

#define ndMesh3dTranslate \
				RET_VOID(MESH3D * mesh3d, double tx, double ty, double tz) \
				ATT_CALL("ndMesh3dTranslate")))

#define ndMesh3dRotate \
				RET_VOID(MESH3D * mesh3d, double ux, double uy, double uz, double angle) \
				ATT_CALL("ndMesh3dRotate")))


#define OBJECT3D_MESH3D								0
#define OBJECT3D_CURVE3D							1

#define ndObject3dCreate \
				RET_LONG(long type) \
				ATT_CALL("ndObject3dCreate")))

#define ndObject3dSetName \
				RET_VOID(long id_object3d, char * name) \
				ATT_CALL("ndObject3dSetName")))

#define ndObject3dSetColor \
				RET_VOID(long id_object3d, double r, double g, double b) \
				ATT_CALL("ndObject3dSetColor")))

#define ndObject3dSetMesh3d \
				RET_VOID(long id_object3d, MESH3D * mesh3d) \
				ATT_CALL("ndObject3dSetMesh3d")))

#define ndObject3dSetCurve3d \
				RET_VOID(long id_object3d, PT3D * array_pt3d, long nb_pt3d) \
				ATT_CALL("ndObject3dSetCurve3d")))

#define ndObject3dSetTexture \
				RET_VOID(long id_object3d, unsigned char * img_rgb, long width, long height) \
				ATT_CALL("ndObject3dSetTexture")))

#define ndObject3dSetWrapping \
				RET_VOID(long id_object3d, double * array_tx, double * array_ty, long direction) \
				ATT_CALL("ndObject3dSetWrapping")))




















#define attDataAddArrowRGB \
				RET_VOID(long id, double x1, double y1, double x2, double y2, double norm_arrow, const char * name,\
								 double r, double g, double b, long thickness) \
				ATT_CALL("attDataAddArrowRGB")))


#define attMsgBox	\
				RET_VOID(char * title, char * message) \
				ATT_CALL("attMsgBox")))

#define attMsgBoxYNC \
				RET_LONG(char * title, char * message) \
				ATT_CALL("attMsgBoxYNC")))

#define attFileInit	\
				RET_PVOID(long hwnd, char * title) \
				ATT_CALL("attFileInit")))

#define attFileSelectorOpen	\
				RET_LONG(void * data) \
				ATT_CALL("attFileSelectorOpen")))

#define attFileGetName \
				RET_PCHAR(void * data) \
				ATT_CALL("attFileGetName")))

#define attFileSetName \
				RET_VOID(void * data, const char * name) \
				ATT_CALL("attFileSetName")))

#define attFileDestroy \
				RET_VOID(void * data) \
				ATT_CALL("attFileDestroy")))

#define attDialogEnd \
				RET_VOID(long hwnd, long end) \
				ATT_CALL("attDialogEnd")))

#define attExec	\
				RET_VOID(char * function, ...) \
				ATT_CALL("attExec")))

#define attDataGraphNew	\
				RET_VOID(long id_object, char * name, double x1, double y1, double x2, double y2) \
				ATT_CALL("attDataGraphNew")))

#define attDataGraphDelete	\
				RET_VOID(long id_object, char * name) \
				ATT_CALL("attDataGraphDelete")))

#define attDataGraphSetPosition	\
				RET_VOID(long id_object, char * name, double x1, double y1, double x2, double y2) \
				ATT_CALL("attDataGraphSetPosition")))

#define attDataGraphSetOrientation	\
				RET_VOID(long id_object, char * name, double angle) \
				ATT_CALL("attDataGraphSetOrientation")))

#define attDataGraphSetLinear	\
				RET_VOID(long id_object, char * name) \
				ATT_CALL("attDataGraphSetLinear")))

#define attDataGraphSetPolar	\
				RET_VOID(long id_object, char * name) \
				ATT_CALL("attDataGraphSetPolar")))

#define attDataGraphSetAutoRange	\
				RET_VOID(long id_object, char * name) \
				ATT_CALL("attDataGraphSetAutoRange")))

#define attDataGraphSetXRange	\
				RET_VOID(long id_object, char * name, double min, double max) \
				ATT_CALL("attDataGraphSetXRange")))

#define attDataGraphSetYRange	\
				RET_VOID(long id_object, char * name, double min, double max) \
				ATT_CALL("attDataGraphSetYRange")))

#define attDataGraphSetBackgroundVisibility	\
				RET_VOID(long id_object, char * name, long visible) \
				ATT_CALL("attDataGraphSetBackgroundVisibility")))

#define attDataGraphSetBackgroundColor	\
				RET_VOID(long id_object, char * name, double r, double g, double b) \
				ATT_CALL("attDataGraphSetBackgroundColor")))

#define attDataGraphSetBorderVisibility	\
				RET_VOID(long id_object, char * name, long visible) \
				ATT_CALL("attDataGraphSetBorderVisibility")))

#define attDataGraphSetBorderWidth	\
				RET_VOID(long id_object, char * name, long width) \
				ATT_CALL("attDataGraphSetBorderWidth")))

#define attDataGraphSetBorderColor	\
				RET_VOID(long id_object, char * name, double r, double g, double b) \
				ATT_CALL("attDataGraphSetBorderColor")))

#define attDataGraphSetXAxisVisibility	\
				RET_VOID(long id_object, char * name, long visible) \
				ATT_CALL("attDataGraphSetXAxisVisibility")))

#define attDataGraphSetXAxisColor	\
				RET_VOID(long id_object, char * name, double r, double g, double b) \
				ATT_CALL("attDataGraphSetXAxisColor")))

#define attDataGraphSetXAxisWidth	\
				RET_VOID(long id_object, char * name, long width) \
				ATT_CALL("attDataGraphSetXAxisWidth")))

#define attDataGraphSetXAxisPosition	\
				RET_VOID(long id_object, char * name, double position) \
				ATT_CALL("attDataGraphSetXAxisPosition")))

#define attDataGraphSetYAxisVisibility	\
				RET_VOID(long id_object, char * name, long visible) \
				ATT_CALL("attDataGraphSetYAxisVisibility")))

#define attDataGraphSetYAxisColor	\
				RET_VOID(long id_object, char * name, double r, double g, double b) \
				ATT_CALL("attDataGraphSetYAxisColor")))

#define attDataGraphSetYAxisWidth	\
				RET_VOID(long id_object, char * name, long width) \
				ATT_CALL("attDataGraphSetYAxisWidth")))

#define attDataGraphSetYAxisPosition	\
				RET_VOID(long id_object, char * name, double position) \
				ATT_CALL("attDataGraphSetYAxisPosition")))

#define attDataGraphSetXGridVisibility	\
				RET_VOID(long id_object, char * name, long visible) \
				ATT_CALL("attDataGraphSetXGridVisibility")))

#define attDataGraphSetXGridColor	\
				RET_VOID(long id_object, char * name, double r, double g, double b) \
				ATT_CALL("attDataGraphSetXGridColor")))

#define attDataGraphSetYGridVisibility	\
				RET_VOID(long id_object, char * name, long visible) \
				ATT_CALL("attDataGraphSetYGridVisibility")))

#define attDataGraphSetYGridColor	\
				RET_VOID(long id_object, char * name, double r, double g, double b) \
				ATT_CALL("attDataGraphSetYGridColor")))

#define attDataGraphSetXFineGridVisibility	\
				RET_VOID(long id_object, char * name, long visible) \
				ATT_CALL("attDataGraphSetXFineGridVisibility")))

#define attDataGraphSetXFineGridColor	\
				RET_VOID(long id_object, char * name, double r, double g, double b) \
				ATT_CALL("attDataGraphSetXFineGridColor")))

#define attDataGraphSetYFineGridVisibility	\
				RET_VOID(long id_object, char * name, long visible) \
				ATT_CALL("attDataGraphSetYFineGridVisibility")))

#define attDataGraphSetYFineGridColor	\
				RET_VOID(long id_object, char * name, double r, double g, double b) \
				ATT_CALL("attDataGraphSetYFineGridColor")))

#define attDataGraphSetData	\
				RET_VOID(long id_object, char * name, long no, double * x, double * y, long nb) \
				ATT_CALL("attDataGraphSetData")))

#define attDataGraphSetDataVisibility	\
				RET_VOID(long id_object, char * name, long no, long visible) \
				ATT_CALL("attDataGraphSetDataVisibility")))

#define attDataGraphSetDataWidth	\
				RET_VOID(long id_object, char * name, long no, long width) \
				ATT_CALL("attDataGraphSetDataWidth")))

#define attDataGraphSetDataColor	\
				RET_VOID(long id_object, char * name, long no, double r, double g, double b) \
				ATT_CALL("attDataGraphSetDataColor")))

#define attDataAddSurface3d	\
				RET_PVOID(long id_object, \
									double x1, double y1, double z1, \
									double x2, double y2, double z2, \
									double x3, double y3, double z3, \
									double x4, double y4, double z4, \
									double r, double g, double b, \
									double * texture, long width_texture, long height_texture) \
				ATT_CALL("attDataAddSurface3d")))

#define attDataGetPositionFromScreen \
				RET_VOID(long id_object, long x_screen, long y_screen, double * x, double * y, double * z) \
				ATT_CALL("attDataGetPositionFromScreen")))

#define attDataAnimateBegin \
				RET_VOID(long id_object) \
				ATT_CALL("attDataAnimateBegin")))

#define attDataAnimateEnd \
				RET_VOID(long id_object) \
				ATT_CALL("attDataAnimateEnd")))



#define attDataCallbackGetMainHwnd \
				RET_PVOID() \
				ATT_CALL("attDataCallbackGetMainHwnd")))

#define attDataCallbackGetHwnd \
				RET_PVOID(long id_object) \
				ATT_CALL("attDataCallbackGetHwnd")))

#define attDataGetSpace \
				RET_LONG(long id_object, double * offset, double * scale) \
				ATT_CALL("attDataGetSpace")))

#define attDataGetView3D \
				RET_LONG(long id_object) \
				ATT_CALL("attDataGetView3D")))










/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/





typedef struct _ATT_DESC_DIALOG
{
	char title[200];	
	long x, y, dx, dy;
	long style;
	long font_size;
	char font_name[200];
	attfunc mainproc;	
	struct
	{
		long type;
		attfunc proc;
	} msg[200];	
	struct		
	{
		long type;
		char name[200];
		long id;
		long x, y, dx, dy;
	} entry[500];
} ATT_DESC_DIALOG;


/* BOITES DE DIALOGUES */
#define DIALOG_NO								0
#define DIALOG_GROUPBOX					1
#define DIALOG_FINGROUPBOX			2
#define DIALOG_LTEXT						3
#define DIALOG_RTEXT						4
#define DIALOG_CTEXT						5
#define DIALOG_EDIT							6
#define DIALOG_RADIO						7
#define	DIALOG_CHECKBOX					8
#define DIALOG_PUSHBUTTON				9
#define DIALOG_OWNER						10
#define DIALOG_OWNER_EX					11
#define DIALOG_TRACKBAR					12
#define END_DIALOG						DIALOG_NO, "", 0, 0, 0, 0, 0
#define DIALOG_END_GROUPBOX		DIALOG_FINGROUPBOX, "", 0, 0, 0, 0, 0,
#define MSG_NO						0
#define MSG_INIT					1
#define MSG_CMD						2
#define MSG_CLOSE					3
#define MSG_INITWITHDATA	4
#define END_MSG						MSG_NO, (attfunc)NULL
#define NO_MSG						{ END_MSG },
#define FONT_8						8, "MS Sans Serif",
#define STYLE_MIN					0
#define STYLE_NORMAL			1
#define STYLE_FIN					2
#define STYLE_3D					3

#define attDialogRunFromDESC \
				RET_VOID(ATT_DESC_DIALOG * dialog) \
				ATT_CALL("attDialogRunFromDESC")))

#define attDialogWithDataRunFromDESC \
				RET_VOID(ATT_DESC_DIALOG * dialog, void * data) \
				ATT_CALL("attDialogWithDataRunFromDESC")))

#define attDialogModalRunFromDESC	\
				RET_LONG(ATT_DESC_DIALOG * dialog) \
				ATT_CALL("attDialogModalRunFromDESC")))

#define attDialogModalWithDataRunFromDESC	\
				RET_LONG(ATT_DESC_DIALOG * dialog, void * data) \
				ATT_CALL("attDialogModalWithDataRunFromDESC")))

#define attWindowDestroy \
				RET_LONG(long hwnd) \
				ATT_CALL("attWindowDestroy")))

#define attWindowEnableItem	\
				RET_VOID(long hwnd, long id, long state) \
				ATT_CALL("attWindowEnableItem")))

#define attWindowCheckRadioButton	\
				RET_VOID(long hwnd, long id1, long id2, long id_active) \
				ATT_CALL("attWindowCheckRadioButton")))

#define attWindowCheckButton \
				RET_VOID(long hwnd, long id, long state) \
				ATT_CALL("attWindowCheckButton")))

#define attWindowModifyItemReal	\
				RET_VOID(long hwnd, long id, double * variable, long sign) \
				ATT_CALL("attWindowModifyItemReal")))

#define attWindowModifyItemRealMinMax	\
				RET_VOID(long hwnd, long id, double * variable, double min, double max) \
				ATT_CALL("attWindowModifyItemRealMinMax")))

#define attWindowModifyItemInt \
				RET_VOID(long hwnd, long id, long * variable, long even, long sign) \
				ATT_CALL("attWindowModifyItemInt")))

#define attWindowModifyItemIntMinMax \
				RET_VOID(long hwnd, long id, long * variable, long min, long max) \
				ATT_CALL("attWindowModifyItemIntMinMax")))

#define attWindowSetItemReal \
				RET_VOID(long hwnd, long id, double l) \
				ATT_CALL("attWindowSetItemReal")))

#define attWindowSetItemReal2	\
				RET_VOID(long hwnd, long id, double l) \
				ATT_CALL("attWindowSetItemReal2")))

#define attWindowSetItemInt	\
				RET_VOID(long hwnd, long id, long variable) \
				ATT_CALL("attWindowSetItemInt")))

#define attWindowGetItemText \
				RET_VOID(long hwnd, long id, char * string, long size) \
				ATT_CALL("attWindowGetItemText")))

#define attWindowSetItemText \
				RET_VOID(long hwnd, long id, char * string) \
				ATT_CALL("attWindowSetItemText")))

#define attWindowClose \
				RET_VOID(long hwnd) \
				ATT_CALL("attWindowClose")))

/* Types */
typedef int BOOL;		

/* Identificateurs */
#if !defined (TRUE)
	#define TRUE	1
#endif
#if !defined (FALSE)
	#define FALSE	0
#endif
#if !defined (NULL)
	#define NULL 0
#endif
#if !defined (PI_DOUBLE)
	#define PI_DOUBLE  6.28318530718
#endif
#if !defined (PI)
	#define PI         3.14159265359	
#endif
#if !defined (DEMI_PI)
	#define DEMI_PI		 1.57079632679	
#endif

/* Fonctions Math�matiques */
#if !defined (MIN)
	#define MIN(x,y)		( ( x >= y ) ? y : x )
#endif
#if !defined (MAX)
	#define MAX(x,y)		( ( x >= y ) ? x : y )
#endif
#if !defined (SGN)
	#define SGN(x)			( ( x >= 0 ) ? (1) : (-1) )
#endif	
#if !defined (RDOUBLE)
	#define RDOUBLE(x)	( floor(x+0.5) )
#endif
#if !defined (RLONG)
	#define RLONG(x)		( (long)floor(x+0.5) )
#endif
#if !defined (CLONG)
	#define CLONG(x)		( (long)ceil(x+0.5) )
#endif

#define DEGFROMRAD	 57.29577951307
#define RADTODEG(x)	( x*DEGFROMRAD)
#define DEGTORAD(x)	( x/DEGFROMRAD)

#define LIST_INC(x)						x = (x)->next;
#define LIST_DEC(x)						x = (x)->prev;
#define LIST_ADDR_INC(x)			x = &((*x)->next);
#define LIST_LAST(list)				while ( list->next != NULL ) LIST_INC(list)
#define IS_LIST_NEXT(list)		( (list)->next != NULL )
#define IS_LIST_PREV(list)		( (list)->prev != NULL )
#define LIST_NEXT(x)					( (x)->next )
#define LIST_PREV(x)					( (x)->prev )
#define LIST_DETACH(x)				(x)->prev = (x)->next = NULL;

#define LIST_ATTACH(list_element_prev, list_attach) \
	{ \
		if ( list_element_prev != NULL ) (list_element_prev)->next = list_attach; \
		if ( list_attach != NULL ) (list_attach)->precedent = list_element_prev; \
	}
#define LIST_INSERT(list_element_prev, list_element_insert) \
	{ \
		(list_element_insert)->prev = list_element_prev; \
		(list_element_insert)->next = LIST_NEXT(list_element_prev); \
		(list_element_prev)->next = list_element_insert; \
		if ( LIST_NEXT(list_element_prev) ) (list_element_prev)->next->prev = list_element_insert; \
	}
#define LIST_INSERT_BEGIN(list_begin, list_element) \
	{ \
		(list_element)->next = list_begin; \
		if ( list_begin != NULL ) (list_begin)->prev = list_element; \
		list_begin = list_element; \
	}
#define LIST_INSERT_AFTER_BEGIN(list_begin, list_element) \
	{ \
		if ( list_begin == NULL ) list_begin = list_element; \
		else \
			{ \
				(list_element)->prev = list_begin; \
				(list_element)->next = LIST_NEXT(list_begin); \
				if ( IS_LIST_PREV(list_element) ) (list_element)->prev->next = list_element; \
				if ( IS_LIST_NEXT(list_element) ) (list_element)->next->prev = list_element; \
			} \
	}
#define LIST_NEW(list_begin, list_element, list_size) \
	{ \
		list_element = (list_size *) calloc (1, sizeof(list_size)); \
		LIST_INSERT_BEGIN(list_begin, list_element) \
	}
#define LIST_CUT(list_element) \
	{ \
		if ( IS_LIST_NEXT(list_element) ) (list_element)->next->prev = LIST_PREV(list_element); \
		if ( IS_LIST_PREV(list_element) ) (list_element)->prev->next = LIST_NEXT(list_element); \
	}
#define LIST_DELETE(list_begin, list_element) \
	{ \
		LIST_CUT(list_element) \
		if ( list_begin == list_element ) list_begin = LIST_NEXT(list_element); \
		free (list_element); \
	}


#endif






